<?php
    $host = 'localhost';
    $database = 'alakazam';
    $name = 'root';
    $passwd = '111111';
    $db_port = 3306;
?>
