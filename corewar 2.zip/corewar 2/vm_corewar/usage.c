/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   usage.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/27 12:41:12 by yholub            #+#    #+#             */
/*   Updated: 2018/08/27 12:41:12 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void				print_usage(void)
{
	ft_printf("Usage: ./corewar [[-n number] champion1.cor] ...\n");
	ft_printf("________________________flags_________________________\n");
	ft_printf("| %-20s %-30s|\n", "-dump <nbr_cycles>",
			"dump memory after nbr_cycles");
	ft_printf("| %-20s %-30s|\n", "-v", "<visualization>");
	ft_printf("|____________________________________________________|\n");
}
