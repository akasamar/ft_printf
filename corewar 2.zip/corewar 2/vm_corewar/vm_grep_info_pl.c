/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vm_grep_info_pl.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/17 17:10:15 by yholub            #+#    #+#             */
/*   Updated: 2018/08/17 17:10:15 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void	printf_info_pl(t_vm *v)
{
	int i;

	i = 0;
	ft_printf("Introducing contestants...\n");
	while (i < v->cou_pl)
	{
		ft_printf("* Player %i, weighing %i bytes, \"%s\" (\"%s\") !\n", i + 1,
				v->p[i].head->prog_size, v->p[i].head->prog_name,
				v->p[i].head->comment);
		i++;
	}
}

void	get_player_infor(t_vm *v, int i)
{
	unsigned int	buff;

	buff = 0;
	get_magic_head(v->p[i]);
	read(v->p[i].fd, &v->p[i].head->prog_name, PROG_NAME_LENGTH);
	read(v->p[i].fd, &buff, 4);
	if (buff != 0)
	{
		ft_printf("No null after name\n");
		exit(1);
	}
	get_size_of_bot(v->p[i]);
	read(v->p[i].fd, &v->p[i].head->comment, COMMENT_LENGTH);
	read(v->p[i].fd, &buff, 4);
	if (buff != 0)
	{
		ft_printf("No null after comment\n");
		exit(1);
	}
	read(v->p[i].fd, v->p[i].code, v->p[i].head->prog_size);
	if (SIZE_DEC + v->p[i].head->prog_size != lseek(v->p[i].fd, 0, SEEK_END))
	{
		ft_printf("Size error\n");
		exit(1);
	}
}

void	vm_grap_pl_infp(t_vm *v)
{
	int i;

	i = 0;
	while (i < v->cou_pl)
	{
		get_player_infor(v, i);
		if (v->p[i].head->prog_size > CHAMP_MAX_SIZE)
		{
			ft_printf("Specified not valid size\n");
			exit(1);
		}
		i++;
	}
	printf_info_pl(v);
}
