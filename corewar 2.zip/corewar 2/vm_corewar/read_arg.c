/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_arg.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/29 11:27:33 by yholub            #+#    #+#             */
/*   Updated: 2018/08/29 11:27:33 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

unsigned int	get_integer_arg(unsigned int *str, int size)
{
	char			*temp;
	char			*res;
	char			*buff;
	unsigned int	head;
	int				i;

	i = 1;
	res = itoa_base(str[0], 16);
	while (i < size)
	{
		temp = ft_strdup(res);
		ft_strdel(&res);
		buff = itoa_base(str[i], 16);
		if (ft_strlen(buff) == 1)
			buff = ft_get_correct(buff);
		res = ft_strjoin(temp, buff);
		ft_strdel(&buff);
		ft_strdel(&temp);
		i++;
	}
	head = (unsigned int)ft_atoi_base(res, 16);
	ft_strdel(&res);
	return (head);
}

unsigned int	read_arg_dir(t_vm *v, int i)
{
	unsigned int	*buff;
	unsigned int	res;
	int				j;

	buff = (unsigned int *)malloc(sizeof(unsigned int) * 4);
	j = 0;
	while (j < 4)
	{
		i = ger_real_pos(i);
		if (i + j < MEM_SIZE)
			buff[j] = v->ar[i].val;
		else
			buff[j] = 0;
		j++;
		i++;
	}
	res = get_integer_arg(buff, 4);
	free(buff);
	return (res);
}

short			read_arg_idx(t_vm *v, int i)
{
	unsigned int	*buff;
	short			res;
	int				j;

	buff = (unsigned int *)malloc(sizeof(unsigned int) * 2);
	j = 0;
	while (j < 2)
	{
		i = ger_real_pos(i);
		if (i + j < MEM_SIZE)
			buff[j] = v->ar[i].val;
		else
			buff[j] = 0;
		j++;
		i++;
	}
	res = (short)get_integer_arg(buff, 2);
	free(buff);
	return (res);
}
