/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op_list_1.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 17:11:55 by yholub            #+#    #+#             */
/*   Updated: 2018/08/28 17:11:56 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void	ft_ld(t_vm *v, t_kar *car)
{
	char	*cod;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (cod[0] == '1' && cod[1] == '0' && cod[2] == '0' && cod[3] == '1')
	{
		change_carry_reg(car, v->ar[car->pos + 6].val,
				read_arg_dir(v, car->pos + 2));
		car->pos = car->pos + 7;
	}
	else if (cod[0] == '1' && cod[1] == '1' && cod[2] == '0' && cod[3] == '1')
	{
		change_carry_reg(car,
						v->ar[car->pos + 4].val, read_arg_dir(v, car->pos +
						read_arg_idx(v, car->pos + 2) % IDX_MOD));
		car->pos = car->pos + 5;
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_st(t_vm *v, t_kar *car)
{
	char	*cod;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (cod[0] == '0' && cod[1] == '1' && cod[2] == '0' && cod[3] == '1')
	{
		st_reg_reg(car, v->ar[car->pos + 2].val, v->ar[car->pos + 3].val);
		car->pos = car->pos + 4;
	}
	else if (cod[0] == '0' && cod[1] == '1' && cod[2] == '1' && cod[3] == '1')
	{
		st_reg_idx(v, car, v->ar[car->pos + 2].val);
		car->pos = car->pos + 5;
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_add(t_vm *v, t_kar *car)
{
	char	*cod;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (cod[0] == '0' && cod[1] == '1' && cod[2] == '0' && cod[3] == '1' &&
			cod[4] == '0' && cod[5] == '1')
	{
		if (v->ar[car->pos + 2].val - 1 >= 0 &&
		v->ar[car->pos + 2].val - 1 < 16)
			if (v->ar[car->pos + 3].val - 1 >= 0 &&
			v->ar[car->pos + 3].val - 1 < 16)
				if (v->ar[car->pos + 4].val - 1 >= 0 &&
				v->ar[car->pos + 4].val - 1 < 16)
				{
					car->reg[v->ar[car->pos + 4].val - 1] =
							car->reg[v->ar[car->pos + 2].val - 1] +
									car->reg[v->ar[car->pos + 3].val - 1];
					carry_change(car, car->reg[v->ar[car->pos + 4].val - 1]);
					car->pos = car->pos + 4;
				}
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_sub(t_vm *v, t_kar *car)
{
	char	*cod;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (cod[0] == '0' && cod[1] == '1' && cod[2] == '0' && cod[3] == '1' &&
			cod[4] == '0' && cod[5] == '1')
	{
		if (v->ar[car->pos + 2].val - 1 >= 0 &&
		v->ar[car->pos + 2].val - 1 < 16)
			if (v->ar[car->pos + 3].val - 1 >= 0 &&
			v->ar[car->pos + 3].val - 1 < 16)
				if (v->ar[car->pos + 4].val - 1 >= 0 &&
				v->ar[car->pos + 4].val - 1 < 16)
				{
					car->reg[v->ar[car->pos + 4].val - 1] =
							car->reg[v->ar[car->pos + 2].val - 1] -
									car->reg[v->ar[car->pos + 3].val - 1];
					carry_change(car, car->reg[v->ar[car->pos + 4].val - 1]);
					car->pos = car->pos + 4;
				}
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_and(t_vm *v, t_kar *car)
{
	char	*cod;
	char	*f_arg;
	char	*s_arg;
	char	*res;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (is_valid_codage(cod) != 0 && is_valid_codage(cod + 2) != 0
			&& is_valid_codage(cod + 4) == 1)
	{
		f_arg = take_fir_arg(cod, car, v);
		s_arg = take_sec_arg(cod, car, v);
		if (f_arg && s_arg)
		{
			res = ft_add_arr(f_arg, s_arg);
			add_two_arg(res, car, v, is_valid_codage(cod) +
			is_valid_codage(cod + 2));
		}
		car->pos = car->pos + 2 + is_valid_codage(cod) +
				is_valid_codage(cod + 2);
		free_kkk(f_arg, s_arg);
		ft_strdel(&res);
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}
