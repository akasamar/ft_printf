/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op_list_2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 17:12:02 by yholub            #+#    #+#             */
/*   Updated: 2018/08/28 17:12:02 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void	ft_or(t_vm *v, t_kar *car)
{
	char	*cod;
	char	*f_arg;
	char	*s_arg;
	char	*res;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (is_valid_codage(cod) != 0 && is_valid_codage(cod + 2) != 0
			&& is_valid_codage(cod + 4) == 1)
	{
		f_arg = take_fir_arg(cod, car, v);
		s_arg = take_sec_arg(cod, car, v);
		if (f_arg && s_arg)
		{
			res = ft_or_arr(f_arg, s_arg);
			add_two_arg(res, car, v, is_valid_codage(cod) +
			is_valid_codage(cod + 2));
		}
		car->pos = car->pos + 2 + is_valid_codage(cod) +
				is_valid_codage(cod + 2);
		free_kkk(f_arg, s_arg);
		ft_strdel(&res);
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_xor(t_vm *v, t_kar *car)
{
	char	*cod;
	char	*f_arg;
	char	*s_arg;
	char	*res;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (is_valid_codage(cod) != 0 && is_valid_codage(cod + 2) != 0
			&& is_valid_codage(cod + 4) == 1)
	{
		f_arg = take_fir_arg(cod, car, v);
		s_arg = take_sec_arg(cod, car, v);
		if (f_arg && s_arg)
		{
			res = ft_xor_arr(f_arg, s_arg);
			add_two_arg(res, car, v, is_valid_codage(cod) +
			is_valid_codage(cod + 2));
		}
		car->pos = car->pos + 2 + is_valid_codage(cod) +
				is_valid_codage(cod + 2);
		free_kkk(f_arg, s_arg);
		ft_strdel(&res);
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_zjmp(t_vm *v, t_kar *car)
{
	int step;

	if (car->carry == 1)
	{
		step = (read_arg_idx(v, car->pos + 1) % IDX_MOD) + car->pos;
		if (step < 0)
			step = step + MEM_SIZE;
		car->pos = step;
	}
	else
		car->pos++;
}

void	ft_ldi(t_vm *v, t_kar *car)
{
	char			*cod;
	unsigned int	fir;
	unsigned int	sec;
	int				sp;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (is_valid_codage(cod) != 0 &&
			(is_valid_codage(cod + 2) == 1 || is_valid_codage(cod + 2) == 4) &&
			is_valid_codage(cod + 4) == 1)
	{
		fir = ft_take_farg(cod, car, v);
		sec = ft_take_sarg(cod, car, v);
		sp = sp_size(cod);
		if (v->ar[car->pos + 2 + sp].val - 1 >= 0 &&
				v->ar[car->pos + 2 + sp].val - 1 < 16)
		{
			car->reg[v->ar[car->pos + 2 + sp].val - 1] =
					read_arg_dir(v, ((fir + sec) % IDX_MOD) + car->pos);
			car->pos = car->pos + 2 + sp + 1;
		}
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}

void	ft_sti(t_vm *v, t_kar *car)
{
	char			*cod;
	int				thr;
	int				sec;
	int				sp;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (is_valid_codage(cod) == 1 && is_valid_codage(cod + 2) != 0 &&
			(is_valid_codage(cod + 4) == 1 || is_valid_codage(cod + 4) == 4))
	{
		sec = sec_arg_sti(cod, car, v);
		thr = thr_arg_sti(cod, car, v);
		sp = sti_sp_size(cod);
		if (v->ar[car->pos + 2].val - 1 >= 0 &&
				v->ar[car->pos + 2].val - 1 < 16)
		{
			sti_reg_idx(v, car, v->ar[car->pos + 2].val, (sec + thr) % IDX_MOD);
			car->pos = car->pos + 2 + sp + 1;
		}
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}
