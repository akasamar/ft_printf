#include "../includes/vm_cw.h"

int		is_pos(int y, t_vm *v)
{
	t_kar *tmp;

	tmp = v->kar;
	while (v->kar)
	{
		if (v->kar->pos == y)
		{
			v->kar = tmp;
			return (1);
		}
		v->kar = v->kar->next;
	}
	v->kar = tmp;
	return (0);
}

void	caryyyyyys(t_kar *car)
{
	while (car)
	{
		ft_printf("carry is %i\n", car->carry);
		car = car->next;
	}
}

void	print_result(t_vm *v, t_flags *fl)
{
	/*int i = 0;
	int j = 0;
	int k = 0;*/
	int x = 0;
	//int proc_n = 0;
	int y = 0;
	//int car = 0;
//	t_kar *temp;

	fl->cycle++;
	/*ft_printf("Flags dump %i, cycle to dump %i, visual %i\n", fl->dump, fl->cycle, fl->v);
	ft_printf("Player info\n");
	while (i < v->cou_pl)
	{
		j = 0;
		ft_printf("number <%i>, player name <%s>, magic %.08x, player coment <%s>, player size <%i>\n",v->p[i].p_n ,v->p[i].head->prog_name, v->p[i].head->magic, v->p[i].head->comment, v->p[i].head->prog_size);
		while (j < (int)v->p[i].head->prog_size)
		{
			k = 0;
			while (j < (int)v->p[i].head->prog_size && k < 16)
			{
				ft_printf("%.2x ", v->p[i].code[j]);
				j++;
				k++;
			}
			ft_printf("\n");
		}
		i++;
	}*/
	while (y < MEM_SIZE)
	{
		x = 0;
		while (x < 64)
		{
			if (is_pos(y, v))
				ft_printf(ANSI_COLOR_CYAN "%.2x ", v->ar[y].val);
			else if (v->ar[y].player == 0)
				ft_printf(ANSI_COLOR_RESET "%.2x ", v->ar[y].val);
			else if (v->ar[y].player == v->p[0].p_n)
				ft_printf(ANSI_COLOR_RED "%.2x ", v->ar[y].val);
			else if (v->ar[y].player == v->p[1].p_n)
				ft_printf(ANSI_COLOR_BLUE "%.2x ", v->ar[y].val);
			else if (v->ar[y].player == v->p[2].p_n)
				ft_printf(ANSI_COLOR_GREEN "%.2x ", v->ar[y].val);
			else if (v->ar[y].player == v->p[3].p_n)
				ft_printf(ANSI_COLOR_YELLOW "%.2x ", v->ar[y].val);
			y++;
			x++;
		}
		ft_printf(ANSI_COLOR_RESET "\n");
	}
	/*temp = v->kar;
	while (temp)
	{
		ft_printf("proces %i\n", proc_n);
		//car = 0;
		while (car < 16)
		{
			ft_printf("car %i <%i>\n", car, temp->reg[car]);
			car++;
		}
		ft_printf("live %i\nPlayer %i\nPosition y %i x%i\n", temp->live, temp->player, temp->pos / 64, temp->pos % 64);
		ft_printf("cycle %i\ncary %i\n", temp->cycles, temp->carry);
		ft_printf("\n");
		proc_n++;
		temp = temp->next;
	}*/
}