/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op_list_4.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 17:12:11 by yholub            #+#    #+#             */
/*   Updated: 2018/08/28 17:12:12 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void	st_reg_reg(t_kar *car, unsigned char src, unsigned char dst)
{
	if (src - 1 >= 0 && src - 1 < 16 && dst - 1 >= 0 && dst - 1 < 16)
		car->reg[dst] = car->reg[src];
}

void	carry_change(t_kar *car, int i)
{
	if (i == 0)
		car->carry = 1;
	else
		car->carry = 0;
}

void	change_carry_reg(t_kar *car, unsigned char i, unsigned int val)
{
	if (i - 1 >= 0 && i - 1 < 16)
	{
		car->reg[i - 1] = val;
		carry_change(car, car->reg[i - 1]);
	}
}

void	ft_aff(t_vm *v, t_kar *car)
{
	char	*cod;

	cod = ft_from16to2(v->ar[car->pos + 1].val);
	if (is_valid_codage(cod) == 1)
	{
		car->pos = car->pos + 3;
	}
	else
		car->pos = car->pos + 2;
	free(cod);
}
