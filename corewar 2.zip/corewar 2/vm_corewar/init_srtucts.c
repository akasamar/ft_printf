/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_srtucts.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/17 12:41:39 by yholub            #+#    #+#             */
/*   Updated: 2018/08/17 12:41:39 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

t_flags		*init_flags(void)
{
	t_flags		*res;

	res = (t_flags *)malloc(sizeof(t_flags));
	res->dump = 0;
	res->cycle = 0;
	res->v = 0;
	return (res);
}

t_vm		*init_vm_struct(char **argv, int argc)
{
	t_vm	*res;
	int		players;
	int		i;

	i = 0;
	players = count_corf(argv, argc);
	res = (t_vm *)malloc(sizeof(t_vm));
	res->cou_pl = 0;
	res->iter = 0;
	res->ctd = CYCLE_TO_DIE;
	res->ctd2 = 0;
	res->ch_c = 0;
	res->cycl = 0;
	res->p = (t_player *)malloc(sizeof(t_player) * players);
	while (i < players)
	{
		res->p[i].head = (t_header*)malloc(sizeof(t_header));
		res->p[i].live = 0;
		res->p[i].lv_p = 0;
		res->p[i].death_oreder = 0;
		i++;
	}
	res->p->p_n = -1;
	return (res);
}

int		ger_real_pos(int p)
{
	if (p < 0)
	{
		p = MEM_SIZE + p;
		return (p);
	}
	else if (p >= MEM_SIZE)
	{
		p = p % MEM_SIZE;
		return (p);
	}
	else
		return (p);
}