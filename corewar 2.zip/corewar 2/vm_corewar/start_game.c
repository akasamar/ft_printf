/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   start_game.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 16:42:19 by yholub            #+#    #+#             */
/*   Updated: 2018/08/28 16:42:19 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void	cw_get_winner(t_vm *v)
{
	int		i;
	int		j;
	int		res;

	res = 0;
	i = 0;
	j = 0;
	while (i < v->cou_pl)
	{
		if (v->p[i].death_oreder >= res)
		{
			res = v->p[i].death_oreder;
			j = i;
		}
		i++;
	}
	ft_printf("Contestant %i, \"%s\", has won !\n",
			j + 1, v->p[j].head->prog_name);
}

int		cou_proc(t_kar *car)
{
	int		i;
	t_kar	*temp;

	i = 0;
	if (car == NULL)
		return (0);
	temp = car;
	while (temp)
	{
		i++;
		temp = temp->next;
	}
	return (i);
}

void	ft_after_op(t_kar *temp)
{
	temp->com = 0;
	if (temp->pos >= MEM_SIZE)
		temp->pos = temp->pos % MEM_SIZE;
}

void	compl_car(t_kar *temp, t_vm *v)
{
	if (temp->com == 0)
		set_op_to_car(temp, v);
	if (temp->cycles == 0)
	{
		ft_operations(v, temp);
		ft_after_op(temp);
	}
	if (temp->cycles > 0)
		temp->cycles--;
}

t_area *create_prev_area(t_area *s1)
{
	t_area	*p;
	int		i;

	i = 0;
	p = (t_area *)malloc(sizeof(t_area) * MEM_SIZE + 1);
	while (i < MEM_SIZE)
	{
		p[i].val = s1[i].val;
		i++;
	}
	return (p);
}

void	begin_game(t_vm *v, t_flags *f)
{
	t_kar	*temp;
	t_area	*cmp;

	init_visual(v, f);
	cmp = create_prev_area(v->ar);
	while (v->ctd > 0 && cou_proc(v->kar))
	{
		while (v->iter < v->ctd)
		{
			cw_dump(v, f);
			visual(v, f, cmp);
			temp = v->kar;
			while (temp)
			{
				compl_car(temp, v);
				temp = temp->next;
			}
			v->iter++;
			v->cycl++;
		}
		check_live(v);
	}
	end_vis(f);
	cw_get_winner(v);
}
