/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_input.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/17 14:29:14 by yholub            #+#    #+#             */
/*   Updated: 2018/08/17 14:29:15 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void	check_fd(int fd)
{
	if (fd <= 0)
	{
		ft_printf("Not valid file\n");
		exit(1);
	}
}

int		vm_set_dump(t_flags *fl, char **str, int i)
{
	if (!str[i + 1])
	{
		ft_printf("Wrong number of cycles\n");
		exit(1);
	}
	else if (ft_atoi(str[i + 1]) > 0 && (int)ft_strlen(str[i + 1])
			== num_size(ft_atoi(str[i + 1])))
	{
		fl->dump = 1;
		fl->cycle = ft_atoi(str[i + 1]);
		return (1);
	}
	else if (ft_atoi(str[i + 1]) == 0 && ft_strlen(str[i + 1]) == 1 &&
	str[i + 1][0] == '0')
	{
		fl->dump = 1;
		fl->cycle = ft_atoi(str[i + 1]);
		return (1);
	}
	else
	{
		ft_printf("Wrong number of cycles\n");
		exit(1);
	}
}

int		get_player_number(t_vm *v, int pos, char *num, char *file)
{
	if (!num || !file)
	{
		ft_printf("Wrong input information\n");
		exit(1);
	}
	if (ft_atoi(num) != 0 || (ft_atoi(num) == 0 &&
			ft_strlen(num) == 1 && num[0] == '0'))
	{
		if (is_cor_format(file) == 0)
		{
			ft_printf("Wrong file format\n");
			exit(1);
		}
		if (ft_atoi(num) != 0 && num_size(ft_atoi(num)) == (int)ft_strlen(num))
		{
			v->p[pos].p_n = ft_atoi(num);
			v->p[pos].fd = open(file, O_RDONLY);
			check_fd(v->p[pos].fd);
			return (2);
		}
	}
	ft_printf("Wrong input information\n");
	exit(1);
}

int		vm_get_player(char *file, int pos, t_vm *v)
{
	v->p[pos].p_n = (pos + 1) * -1;
	v->p[pos].fd = open(file, O_RDONLY);
	check_fd(v->p[pos].fd);
	return (1);
}

void	ft_parse_args(t_flags *fl, t_vm *v, char **argv, int argc)
{
	int i;

	i = 1;
	while (i < argc)
	{
		if (!ft_strcmp(argv[i], "-dump"))
			i += vm_set_dump(fl, argv, i);
		else if (!ft_strcmp(argv[i], "-v"))
			fl->v = 1;
		else if (!ft_strcmp(argv[i], "-n"))
		{
			i += get_player_number(v, v->cou_pl, argv[i + 1], argv[i + 2]);
			v->cou_pl++;
		}
		else if (is_cor_format(argv[i]))
			v->cou_pl += vm_get_player(argv[i], v->cou_pl, v);
		else
		{
			ft_printf("Wrong input format\n");
			exit(1);
		}
		i++;
	}
	if (v->cou_pl > 4 || v->cou_pl == 0)
		exit_prog_err();
}
