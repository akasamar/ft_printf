/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vm_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/17 09:49:42 by yholub            #+#    #+#             */
/*   Updated: 2018/08/17 09:49:43 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

int		main(int argc, char **argv)
{
	t_flags		*fl;
	t_vm		*v;

	if (argc > 1)
	{
		fl = init_flags();
		v = init_vm_struct(argv, argc);
		ft_parse_args(fl, v, argv, argc);
		vm_grap_pl_infp(v);
		set_players(v);
		begin_game(v, fl);
	}
	else
		print_usage();
	return (0);
}
