/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op_func.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <yholub@student.unit.ua>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/29 15:31:20 by yholub            #+#    #+#             */
/*   Updated: 2018/08/29 15:31:20 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

char			**fill_mass_by(char *val)
{
	char	**mas;
	int		i;
	int		len;

	i = 0;
	len = (int)ft_strlen(val) - 1;
	mas = (char**)malloc(sizeof(mas) * 4);
	while (i < 4)
	{
		mas[i] = (char *)malloc(sizeof(char) * 2);
		mas[i][0] = '0';
		mas[i][1] = '0';
		i++;
	}
	i = 3;
	while (len >= 0)
	{
		mas[i][1] = val[len];
		len--;
		if (len >= 0)
			mas[i][0] = val[len];
		len--;
		i--;
	}
	return (mas);
}

unsigned char	*separate_to_for(unsigned int val)
{
	unsigned char	*res;
	char			*temp;
	char			**mas;
	int				i;

	i = 0;
	temp = itoa_base(val, 16);
	mas = fill_mass_by(temp);
	res = (unsigned char *)malloc(sizeof(unsigned char) * 4);
	while (i < 4)
	{
		res[i] = (unsigned char)ft_atoi_base(mas[i], 16);
		i++;
	}
	ft_strdel(&temp);
	i = -1;
	while (++i < 4)
		free(mas[i]);
	free(mas);
	return (res);
}

void			st_reg_idx(t_vm *v, t_kar *car, unsigned char num)
{
	unsigned char	*four;
	int				i;
	int				p;

	v->cou_pl += 0;
	if (num - 1 >= 0 && num - 1 < 16)
	{
		i = 0;
		four = separate_to_for((unsigned int)car->reg[num - 1]);
		p = car->pos + (read_arg_idx(v, car->pos + 3) % IDX_MOD);
		p = ger_real_pos(p);
		while (i < 4)
		{
			if (p > MEM_SIZE - 1)
				p = p % MEM_SIZE;
			v->ar[p].val = four[i];
			v->ar[p].player = car->player;
			v->ar[p].col = 1;
			i++;
			p++;
		}
		free(four);
	}
}

void			sti_reg_idx(t_vm *v, t_kar *car, unsigned char num, int pl)
{
	unsigned char	*four;
	int				i;
	int				p;

	v->cou_pl += 0;
	if (num - 1 >= 0 && num - 1 < 16)
	{
		i = 0;
		four = separate_to_for((unsigned int)car->reg[num - 1]);
		p = car->pos + pl;
		p = ger_real_pos(p);
		while (i < 4)
		{
			if (p > MEM_SIZE - 1)
				p = p % MEM_SIZE;
			v->ar[p].val = four[i];
			v->ar[p].player = car->player;
			i++;
			p++;
		}
		free(four);
	}
}
