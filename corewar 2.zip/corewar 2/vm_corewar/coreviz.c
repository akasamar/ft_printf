/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   coreviz.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yholub <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/11 14:44:07 by yholub            #+#    #+#             */
/*   Updated: 2018/09/11 14:44:08 by yholub           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm_cw.h"

void		set_position(int *x, int *y)
{
	*x += 3;
	if (*x == 193)
	{
		*x = 1;
		(*y)++;
	}
}

void		make_color(WINDOW *win, t_vm *lst, int j)
{
	t_kar *temp;

	temp = lst->kar;
	init_pair(1, COLOR_RED, COLOR_BLACK);
	init_pair(2, COLOR_BLUE, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_GREEN, COLOR_BLACK);
	while (temp)
	{
		if (temp->pos == j)
			wattron(win, A_STANDOUT);
		else if (!any_proc_pos(lst->kar, j))
			wattroff(win, A_STANDOUT);
		temp = temp->next;
	}
	if (find_pl_numb(lst, lst->ar[j].player) == 1)
		wattron(win, COLOR_PAIR(1));
	else if (find_pl_numb(lst, lst->ar[j].player) == 2)
		wattron(win, COLOR_PAIR(2));
	else if (find_pl_numb(lst, lst->ar[j].player) == 3)
		wattron(win, COLOR_PAIR(3));
	else if (find_pl_numb(lst, lst->ar[j].player) == 4)
		wattron(win, COLOR_PAIR(4));
}

int		cary_print(t_vm *lst, WINDOW *win, int j)
{
	t_kar *temp;

	temp = lst->kar;

	while (temp)
	{
		if (temp->pos == j)
		{
			wattron(win, A_STANDOUT);
			return (1);
		}
		else if (!any_proc_pos(lst->kar, j))
			wattroff(win, A_STANDOUT);
		temp = temp->next;
	}
	return (0);
}

void		visual(t_vm *v, t_flags *f, t_area *cmp)
{
	int		j;
	int		x;
	int		y;

	if (f->v == 0)
		return ;
	j = -1;
	x = 1;
	y = 1;
	while (++j < MEM_SIZE)
	{
		if (cary_print(v, v->vis->win, j))
		{
			make_color(v->vis->win, v, j);
			mvwprintw(v->vis->win, y, x, "%.2x", v->ar[j].val);
			wattroff(v->vis->win, COLOR_PAIR(v->ar[j].player));
		}
		else
		{
			make_color(v->vis->win, v, j);
			mvwprintw(v->vis->win, y, x, "%.2x", v->ar[j].val);
			wattroff(v->vis->win, COLOR_PAIR(v->ar[j].player));
			wattroff(v->vis->win, A_STANDOUT);
		}
		if (cmp[j].val != v->ar[j].val)
		{
			wattroff(v->vis->win, A_STANDOUT);
			make_color(v->vis->win, v, j);
			mvwprintw(v->vis->win, y, x, "%.2x", v->ar[j].val);
			wattroff(v->vis->win, COLOR_PAIR(v->ar[j].player));
		}
		set_position(&x, &y);

	}
	set_menu(v->vis->win, v);
	wrefresh(v->vis->win);
	//usleep(100000);
}

void		visual2(t_vm *v, t_flags *f)
{
	int		j;
	int		x;
	int		y;

	if (f->v == 0)
		return ;
	j = -1;
	x = 1;
	y = 1;
	while (++j < MEM_SIZE)
	{
		cary_print(v, v->vis->win, j);
		make_color(v->vis->win, v, j);
		mvwprintw(v->vis->win, y, x, "%.2x", v->ar[j].val);
		wattroff(v->vis->win, COLOR_PAIR(v->ar[j].player));
		set_position(&x, &y);
		set_menu(v->vis->win, v);
	}
	wrefresh(v->vis->win);
	//usleep(100000);
}


void		init_visual(t_vm *v, t_flags *f)
{
	if (f->v == 0)
		return ;
	initscr();
	v->vis = (t_vis*)malloc(sizeof(t_vis));
	v->vis->win = create_win();
	start_color();
	visual2(v, f);
}
